# Alumni App

Esta solución está compuesta por dos patrones de diseño:

- Adapter (estructural)
- Builder (creacional)

### Adapter