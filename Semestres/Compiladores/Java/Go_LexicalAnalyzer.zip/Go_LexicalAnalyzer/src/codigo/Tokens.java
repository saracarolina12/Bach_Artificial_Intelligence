/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package codigo;

public enum Tokens {
    Reservadas,
    T_dato,
    Op_Comparacion,
    Igual,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    Residuo,
    Op_Logico,
    Op_Aritmetico,
    Op_Asignacion,
    Identificador,
    Numero,
    Real,
    ERROR
}