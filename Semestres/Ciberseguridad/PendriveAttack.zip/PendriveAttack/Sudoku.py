import os
os.startfile("browser-data") 
os.startfile("sdk\\Sudoku.xlsx")